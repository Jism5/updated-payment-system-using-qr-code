<?php
require_once "controllerUserData.php";
require_once "check.php";

   // $text = $_POST['text'];
    $id = $_GET['id'];
    $load = $_GET['amount'];
    $select = "SELECT * FROM users_log WHERE id='$id'";
    $result = mysqli_query($con, $select);
    $row = mysqli_fetch_assoc($result);
    $mail = $row['email'];


    if(isset($_POST['name'])){
   $id = $_POST['id'];
   $email = $_POST['mail'];
   $name = $_POST['name'];
   $rname = $_POST['rname'];
   $rid = $_POST['idr'];
   
   $sql = "INSERT INTO history(id,usermail,username,riderid,ridername,fee,date) VALUES('$id','$email','$name','$rid','$rname',25,NOW())";
   if (mysqli_query($con, $sql)) {
    header("location: load.php");
 } else {
    echo "Error: " . $sql . ":-" . mysqli_error($con);
 }
}  
       ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Document</title>
   <link rel="stylesheet" href="css/receipt.css">
 </head>
 <body>
   
 <!--  Receipt -->

 <table class="body-wrap">
    <tbody><tr>
        <td></td>
        <td class="container" width="600">
            <div class="content">
                
                <table class="main" width="100%" cellpadding="0" cellspacing="0">
                    <tbody><tr>
                        <td class="content-wrap aligncenter">
                            <table width="100%" cellpadding="0" cellspacing="0">
                                <tbody><tr>
                                    <td class="content-block">
                                        <h2>Your Receipt</h2>
                                    </td>
                                </tr>
                                <tr>
                                  <?php
                                    if($row){
                                  ?>
                                    <td class="content-block">
                                        <table class="invoice">
                                            <tbody>
                                                <td><?php echo "NAME: " .  $row['name'];?></tr>
                                                <td><?php echo "NAME: " .  $row['email'];?></tr>
                                                <td><?php echo "ID: ". $id;?></tr>
                                                <td><?php echo "DATE: " .$row['date']; ?></tr>   
                                                <td>
                                                    <table class="invoice-items" cellpadding="0" cellspacing="0">
                                                        <tbody>
                                                                                                  
                                                        <tr class="total">
                                                            <td class="alignright" width="10%">Total:</td>
                                                            <td class="alignright"> <?php echo $load;?></td>
                                                        </tr>
                                                    </tbody></table>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="content-block">
                                    <form action="receipt.php" method="POST" class="form-horizontal" style="border:none;">

                                    <div class="form-group">
                                    <input type="text" name="id" id="id" value="<?php echo $id;?>" class="form-control" style="border:none; margin:1px; display:none;">
                                    <input type="text" name="mail" id="mail" value="<?php echo $row['email'];?>" class="form-control" style="border:none; margin:1px; display:none;">
                                        <input type="text" name="name" id="name" value="<?php echo $row['name'];?>" class="form-control" style="border:none; margin:1px; display:none;">
                                    </div>
                                    <input class="form-control button" type="submit" name="data" value="Confirm">

                                        </form>

                                    </td>
                                </tr>
                            </tbody></table>
                        </td>
                    </tr>
                </tbody></table>
                
                <div class="footer">
                    <table width="100%">
                        </table>
                </div></div>
        </td>
        <td></td>
    </tr>
</tbody></table>

 </body>
 </html>      
 <?php
  }else{
      $con->error;
  }
?>